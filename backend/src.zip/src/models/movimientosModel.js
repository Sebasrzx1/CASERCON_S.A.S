const db = require("../config/conexion_db");

const movimientosModel = {

  // ── Consultar todos los movimientos con detalle completo
  async findAll() {
    const query = `
      SELECT
        mi.id_movimiento,
        mi.tipo_movimiento,
        mi.cantidad,
        mi.fecha,
        mi.observacion,
        mp.nombre        AS nombre_materia,
        mp.codigo        AS codigo_materia,
        cm.nombre_categoria_materia AS categoria,
        l.codigo_lote,
        l.stock_restante AS stock_lote,
        u.nombre         AS usuario,
        p.no_orden_compra AS codigo_orden
      FROM movimientos_inventario mi
      INNER JOIN materias_primas mp ON mi.id_materia = mp.id_materia
      INNER JOIN categoria_materias cm ON mp.id_categoria_materia = cm.id_categoria_materia
      LEFT  JOIN lotes l             ON mi.id_lote = l.id_lote
      LEFT  JOIN usuarios u          ON mi.id_usuario = u.id_usuario
      LEFT  JOIN pedidos p           ON mi.id_pedido = p.id_pedido
      ORDER BY mi.fecha DESC;
    `;
    const [rows] = await db.execute(query);
    return rows;
  },

  // ── Consultar movimientos filtrados por tipo y rango de fechas (informes)
  async findByFiltros({ tipo, fecha_inicio, fecha_fin }) {
    let query = `
      SELECT
        mi.id_movimiento,
        mi.tipo_movimiento,
        mi.cantidad,
        mi.fecha,
        mi.observacion,
        mp.nombre        AS nombre_materia,
        mp.codigo        AS codigo_materia,
        cm.nombre_categoria_materia AS categoria,
        l.codigo_lote,
        u.nombre         AS usuario,
        p.no_orden_compra AS codigo_orden
      FROM movimientos_inventario mi
      INNER JOIN materias_primas mp ON mi.id_materia = mp.id_materia
      INNER JOIN categoria_materias cm ON mp.id_categoria_materia = cm.id_categoria_materia
      LEFT  JOIN lotes l             ON mi.id_lote = l.id_lote
      LEFT  JOIN usuarios u          ON mi.id_usuario = u.id_usuario
      LEFT  JOIN pedidos p           ON mi.id_pedido = p.id_pedido
      WHERE 1=1
    `;
    const params = [];

    if (tipo && tipo !== "Todos") {
      query += ` AND mi.tipo_movimiento = ?`;
      params.push(tipo);
    }
    if (fecha_inicio) {
      query += ` AND DATE(mi.fecha) >= ?`;
      params.push(fecha_inicio);
    }
    if (fecha_fin) {
      query += ` AND DATE(mi.fecha) <= ?`;
      params.push(fecha_fin);
    }

    query += ` ORDER BY mi.fecha DESC;`;
    const [rows] = await db.execute(query, params);
    return rows;
  },

  // ── Obtener lotes activos de una materia prima (para salida)
  async findLotesActivosByMateria(id_materia) {
    const query = `
      SELECT
        l.id_lote,
        l.codigo_lote,
        l.numero_lote,
        l.stock_restante,
        l.fecha_ingreso
      FROM lotes l
      WHERE l.id_materia = ?
        AND l.estado = 'activo'
        AND l.stock_restante > 0
      ORDER BY l.fecha_ingreso ASC;
    `;
    const [rows] = await db.execute(query, [id_materia]);
    return rows;
  },

  // ── Obtener siguiente número de lote para una materia prima
  async getNextNumeroLote(id_materia) {
    const query = `
      SELECT COALESCE(MAX(numero_lote), 0) + 1 AS siguiente
      FROM lotes
      WHERE id_materia = ?;
    `;
    const [rows] = await db.execute(query, [id_materia]);
    return rows[0].siguiente;
  },

  // ── Crear lote nuevo (entrada manual)
  async createLote({ id_materia, abreviacion, cantidad, numero_lote }) {
    const fecha  = new Date();
    const dd     = String(fecha.getDate()).padStart(2, "0");
    const mm     = String(fecha.getMonth() + 1).padStart(2, "0");
    const yyyy   = fecha.getFullYear();
    const codigo_lote = `${abreviacion}-${String(numero_lote).padStart(3, "0")}-${dd}${mm}${yyyy}`;

    const query = `
      INSERT INTO lotes
        (id_materia, numero_lote, id_detalle_pedido, codigo_lote, stock_inicial, stock_restante, estado)
      VALUES (?, ?, NULL, ?, ?, ?, 'activo');
    `;
    const [result] = await db.execute(query, [
      id_materia, numero_lote, codigo_lote, cantidad, cantidad,
    ]);
    return { id_lote: result.insertId, codigo_lote };
  },

  // ── Registrar movimiento de entrada
  async createEntrada({ id_materia, id_lote, id_usuario, cantidad, observacion }) {
    const query = `
      INSERT INTO movimientos_inventario
        (id_materia, id_lote, id_usuario, tipo_movimiento, cantidad, observacion)
      VALUES (?, ?, ?, 'Entrada', ?, ?);
    `;
    const [result] = await db.execute(query, [
      id_materia, id_lote, id_usuario, cantidad, observacion || null,
    ]);
    return result.insertId;
  },

  // ── Registrar movimiento de salida
  async createSalida({ id_materia, id_lote, id_usuario, cantidad, observacion }) {
    const query = `
      INSERT INTO movimientos_inventario
        (id_materia, id_lote, id_usuario, tipo_movimiento, cantidad, observacion)
      VALUES (?, ?, ?, 'Salida', ?, ?);
    `;
    const [result] = await db.execute(query, [
      id_materia, id_lote, id_usuario, cantidad, observacion || null,
    ]);
    return result.insertId;
  },

  // ── Descontar stock del lote
  async descontarStockLote(id_lote, cantidad) {
    const query = `
      UPDATE lotes
      SET stock_restante = stock_restante - ?
      WHERE id_lote = ?;
    `;
    await db.execute(query, [cantidad, id_lote]);
  },

  // ── Obtener lote por ID
  async findLoteById(id_lote) {
    const query = `
      SELECT id_lote, id_materia, stock_restante, estado
      FROM lotes WHERE id_lote = ?;
    `;
    const [rows] = await db.execute(query, [id_lote]);
    return rows[0] || null;
  },

  // ── Obtener materia prima por ID (para validaciones y código)
  async findMateriaById(id_materia) {
    const query = `
      SELECT mp.id_materia, mp.nombre, mp.abreviacion, mp.estado
      FROM materias_primas mp
      WHERE mp.id_materia = ?;
    `;
    const [rows] = await db.execute(query, [id_materia]);
    return rows[0] || null;
  },

};

module.exports = movimientosModel;