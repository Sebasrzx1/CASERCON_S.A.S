const express = require("express");
const router = express.Router();
const movimientosController = require("../controllers/movimientosController");
const { protect, restricTo } = require("../middlewares/authMiddleware");

// GET todos los movimientos
router.get("/", movimientosController.getAllMovimientos);

// GET movimientos filtrados por tipo y fechas (informes)
router.get("/filtros", protect, movimientosController.getMovimientosFiltrados);

// GET lotes activos de una materia prima (para salida)
router.get("/lotes/:id_materia", protect, movimientosController.getLotesByMateria);

// POST registrar entrada manual
router.post("/entrada", protect, restricTo("Administrador"), movimientosController.registrarEntrada);

// POST registrar salida manual
router.post("/salida", protect, restricTo("Administrador"), movimientosController.registrarSalida);

module.exports = router;